export interface RowData {
    thumbnails: string;
    publishedAt: string;
    title: string;
    description: string;
    rowHeight: number;
}
