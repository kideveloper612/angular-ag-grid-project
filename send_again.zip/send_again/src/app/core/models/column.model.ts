export interface ColData {
    headerName: string;
    field: string;
}
